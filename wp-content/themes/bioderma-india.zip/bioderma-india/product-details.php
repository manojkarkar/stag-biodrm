<?php
/*
Template Name: Bioderma around the world
*/
get_header();
?>
    <main class="main spacing-xxl">
                 <article class="post-178 page type-page status-publish hentry">
  <header>
        <figure class="lazyload-wrapper lazyload-wrapper--banner">
        <iframe src="https://www.google.com/maps/d/embed?mid=1czy47zfp806pDNVHfz49ZXfjCKcRPjqh" frameborder="0" style="border:0" allowfullscreen></iframe>
      <div class="aspect-ratio" style="padding-top: 60%"></div>
    </figure>
  </header>
  <style type="text/css">
    .lazyload-wrapper iframe {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;}
  </style>
</article>

          </main>
  
<?php 
get_footer();
?>

       